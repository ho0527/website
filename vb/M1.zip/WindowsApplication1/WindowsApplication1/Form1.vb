﻿Public Class Form1

    Private Sub b1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles b1.Click
        Dim data As String, copy, m1, m2, rev
        FileOpen(1, "C:\11900\1060301.SM", OpenMode.Input)
        Input(1, data)
        FileClose(1)
        copy = data
        For i = 1 To Len(data)
            m1 = copy \ 10
            m2 = copy Mod 10
            rev = rev & m2
            copy = m1
        Next
        If rev = data Then
            t1.Text = "第一題結果 :  " & data & " is a palindrome."
        Else
            t1.Text = "第一題結果 :  " & data & " is not a palindrome."
        End If
    End Sub

    Private Sub b2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles b2.Click
        Dim data, ans
        FileOpen(2, "C:\11900\1060302.SM", OpenMode.Input)
        Input(2, data)
        FileClose(2)
        For i = 1 To data
            For j = 1 To i
                ans = ans & j
            Next
            ans = ans & vbNewLine
        Next
        t2.Text = "第二題結果:" & vbNewLine & ans
    End Sub

    Private Sub b3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles b3.Click
        Dim data, num
        FileOpen(3, "C:\11900\1060303.SM", OpenMode.Input)
        Input(3, data)
        FileClose(3)
        For i = 1 To data
            If data Mod i = 0 Then
                num = num + 1
            End If
        Next
        If num = 2 Then
            t3.Text = "第三題結果 :  " & data & " is a prime number."
        Else
            t3.Text = "第三題結果 :  " & data & " is not a prime number."
        End If
    End Sub

    Private Sub b4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles b4.Click
        Dim h(3), w(3), bmi(3), smallestbmi
        FileOpen(4, "C:\11900\1060304.SM", OpenMode.Input)
        For i = 1 To 3
            Input(4, h(i))
            Input(4, w(i))
            bmi(i) = w(i) / (h(i) / 100) ^ 2
        Next
        FileClose(4)
        smallestbmi = 9999999
        For i = 1 To 3
            If bmi(i) < smallestbmi Then
                smallestbmi = bmi(i)
            End If
        Next
        Dim intbmi As Integer = smallestbmi
        If 20 <= intbmi And intbmi <= 25 Then
            t4.Text = "第四題結果: 最小BMI值=" & intbmi & "，正常"
        Else
            t4.Text = "第四題結果: 最小BMI值=" & intbmi & "，不正常"
        End If
    End Sub

    Private Sub b5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles b5.Click
        Dim a(8), ans(4)
        FileOpen(5, "c:\11900\1060305.sm", OpenMode.Input)
        For i = 1 To 8
            Input(5, a(i))
        Next
        FileClose(5)
        For i = 1 To 4
            ans(i) = a(i) + a(i + 4)
        Next

        t5.Text = "第五題結果：" & vbNewLine & "[" & ans(1) & "       " & ans(2) & "]" & vbNewLine & "[" & ans(3) & "   " & ans(4) & "]"
    End Sub
End Class
