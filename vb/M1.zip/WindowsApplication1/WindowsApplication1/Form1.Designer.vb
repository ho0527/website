﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請不要使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.b1 = New System.Windows.Forms.Button()
        Me.t1 = New System.Windows.Forms.TextBox()
        Me.b2 = New System.Windows.Forms.Button()
        Me.t2 = New System.Windows.Forms.TextBox()
        Me.b3 = New System.Windows.Forms.Button()
        Me.t3 = New System.Windows.Forms.TextBox()
        Me.b4 = New System.Windows.Forms.Button()
        Me.t4 = New System.Windows.Forms.TextBox()
        Me.b5 = New System.Windows.Forms.Button()
        Me.t5 = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'b1
        '
        Me.b1.Location = New System.Drawing.Point(119, 39)
        Me.b1.Name = "b1"
        Me.b1.Size = New System.Drawing.Size(75, 23)
        Me.b1.TabIndex = 0
        Me.b1.Text = "Button1"
        Me.b1.UseVisualStyleBackColor = True
        '
        't1
        '
        Me.t1.Location = New System.Drawing.Point(77, 83)
        Me.t1.Multiline = True
        Me.t1.Name = "t1"
        Me.t1.Size = New System.Drawing.Size(170, 182)
        Me.t1.TabIndex = 1
        '
        'b2
        '
        Me.b2.Location = New System.Drawing.Point(319, 39)
        Me.b2.Name = "b2"
        Me.b2.Size = New System.Drawing.Size(75, 23)
        Me.b2.TabIndex = 0
        Me.b2.Text = "Button1"
        Me.b2.UseVisualStyleBackColor = True
        '
        't2
        '
        Me.t2.Location = New System.Drawing.Point(277, 83)
        Me.t2.Multiline = True
        Me.t2.Name = "t2"
        Me.t2.Size = New System.Drawing.Size(170, 182)
        Me.t2.TabIndex = 1
        '
        'b3
        '
        Me.b3.Location = New System.Drawing.Point(527, 39)
        Me.b3.Name = "b3"
        Me.b3.Size = New System.Drawing.Size(75, 23)
        Me.b3.TabIndex = 0
        Me.b3.Text = "Button1"
        Me.b3.UseVisualStyleBackColor = True
        '
        't3
        '
        Me.t3.Location = New System.Drawing.Point(485, 83)
        Me.t3.Multiline = True
        Me.t3.Name = "t3"
        Me.t3.Size = New System.Drawing.Size(170, 182)
        Me.t3.TabIndex = 1
        '
        'b4
        '
        Me.b4.Location = New System.Drawing.Point(742, 39)
        Me.b4.Name = "b4"
        Me.b4.Size = New System.Drawing.Size(75, 23)
        Me.b4.TabIndex = 0
        Me.b4.Text = "Button1"
        Me.b4.UseVisualStyleBackColor = True
        '
        't4
        '
        Me.t4.Location = New System.Drawing.Point(700, 83)
        Me.t4.Multiline = True
        Me.t4.Name = "t4"
        Me.t4.Size = New System.Drawing.Size(170, 182)
        Me.t4.TabIndex = 1
        '
        'b5
        '
        Me.b5.Location = New System.Drawing.Point(948, 39)
        Me.b5.Name = "b5"
        Me.b5.Size = New System.Drawing.Size(75, 23)
        Me.b5.TabIndex = 0
        Me.b5.Text = "Button1"
        Me.b5.UseVisualStyleBackColor = True
        '
        't5
        '
        Me.t5.Location = New System.Drawing.Point(906, 83)
        Me.t5.Multiline = True
        Me.t5.Name = "t5"
        Me.t5.Size = New System.Drawing.Size(170, 182)
        Me.t5.TabIndex = 1
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1157, 428)
        Me.Controls.Add(Me.t5)
        Me.Controls.Add(Me.t4)
        Me.Controls.Add(Me.t3)
        Me.Controls.Add(Me.t2)
        Me.Controls.Add(Me.t1)
        Me.Controls.Add(Me.b5)
        Me.Controls.Add(Me.b4)
        Me.Controls.Add(Me.b3)
        Me.Controls.Add(Me.b2)
        Me.Controls.Add(Me.b1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents b1 As System.Windows.Forms.Button
    Friend WithEvents t1 As System.Windows.Forms.TextBox
    Friend WithEvents b2 As System.Windows.Forms.Button
    Friend WithEvents t2 As System.Windows.Forms.TextBox
    Friend WithEvents b3 As System.Windows.Forms.Button
    Friend WithEvents t3 As System.Windows.Forms.TextBox
    Friend WithEvents b4 As System.Windows.Forms.Button
    Friend WithEvents t4 As System.Windows.Forms.TextBox
    Friend WithEvents b5 As System.Windows.Forms.Button
    Friend WithEvents t5 As System.Windows.Forms.TextBox

End Class
