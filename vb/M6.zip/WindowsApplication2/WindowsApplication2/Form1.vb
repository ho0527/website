﻿Public Class Form1
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim count, ans(1000, 4), d(9)
        FileOpen(6, "C:\11900\1060306.SM", OpenMode.Input)
        count = 0
        Do While Not EOF(6)
            count = count + 1
            Input(6, ans(count, 1))
            Input(6, ans(count, 2))
            Input(6, ans(count, 3))
        Loop
        FileClose(6)
        For i = 1 To count
            Dim errorcode = ""
            Dim id = ans(i, 1)
            If id Like "[A-Z]#########" Then
                Dim sexcodecheck = Mid(id, 2, 1) & ans(i, 3)
                If sexcodecheck = "1M" Or sexcodecheck = "2F" Then
                    Dim m1 = InStr("ABCDEFGHJKLMNPQRSTUVXYWZIO", Mid(id, 1, 1)) + 9
                    Dim x1 = m1 \ 10
                    Dim x2 = m1 Mod 10
                    For j = 1 To 9
                        d(j) = Mid(id, j + 1, 1)
                    Next
                    If (x1 + x2 * 9 + d(1) * 8 + d(2) * 7 + d(3) * 6 + d(4) * 5 + d(5) * 4 + d(6) * 3 + d(7) * 2 + d(8) + d(9)) Mod 10 = 0 Then
                    Else
                        errorcode = "CHECK SUM ERROR"
                    End If
                Else
                    errorcode = "SEX CODE ERROR"
                End If
            Else
                errorcode = "FORMET ERROR"
            End If
            ans(i, 4) = errorcode
        Next
        Dim tr As New DataTable
        tr.Columns.Add("ID_NO")
        tr.Columns.Add("NAME")
        tr.Columns.Add("SEX")
        tr.Columns.Add("ERROR")
        For i = 1 To count
            Dim td As DataRow = tr.NewRow
            td(0) = ans(i, 1)
            td(1) = ans(i, 2)
            td(2) = ans(i, 3)
            td(3) = ans(i, 4)
            tr.Rows.Add(td)
        Next
        dgv.DataSource = tr
        dgv.Sort(dgv.Columns(0), 0)
    End Sub
End Class
