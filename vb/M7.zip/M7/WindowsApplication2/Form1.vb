﻿Public Class Form1
    Private Sub Form1_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        Dim gametime, data(100), count, color(3)
        'p:player玩家,  b:banker莊家, n:no數字 , f:flower 花色 ->組合如下 : 
        Dim card, pn, pf, pn1, bn, bf, bn1 As New ArrayList 'pn : 玩家數字    pf : 玩家花色    pn1 : 玩家數值 bn : 莊家數字    bf : 莊家花色    bn1:  莊家數值
        FileOpen(7, "c:\11900\1060307.sm", OpenMode.Input)
        Input(7, gametime)          '讀取第1筆資料存入gametime遊戲局數
        count = 0
        Do While Not EOF(7)
            count = count + 1
            Input(7, data(count))
        Loop
        FileClose(7)
        color(0) = System.Text.Encoding.UTF8.GetString({226, 153, 160})
        color(1) = System.Text.Encoding.UTF8.GetString({226, 153, 165})
        color(2) = System.Text.Encoding.UTF8.GetString({226, 153, 166})
        color(3) = System.Text.Encoding.UTF8.GetString({226, 153, 163})
        For i = 1 To count
            Dim t = Int(data(i) * 52)                  '將隨機亂數轉換成卡號
            If card.IndexOf(t) = -1 Then card.Add(t) '如果在card中找不到牌卡t，則將t加入card牌組中
        Next
        For i = 0 To gametime * 2 - 1
            Dim f = card(i) \ 13                 'f : 花色
            Dim n = card(i) Mod 13 + 1                  'n : 點數
            Dim disp = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"}
            Dim n1 = disp(n - 1)                            'n1 : AJQK轉換
            If n = 1 Then
                n = 14 '讓A變成最大點數
            End If
            If i Mod 2 = 0 Then
                pn.Add(n)
                pf.Add(f)
                pn1.Add(n1)
            Else
                bn.Add(n)
                bf.Add(f)
                bn1.Add(n1)
            End If
        Next
        Dim tr As New DataTable
        tr.Columns.Add("序號")
        tr.Columns.Add("玩家")
        tr.Columns.Add("莊家")
        tr.Columns.Add("結果")
        For i = 0 To gametime - 1
            Dim td As DataRow = tr.NewRow
            td(0) = i + 1
            td(1) = color(pf(i)) & pn1(i)
            td(2) = color(bf(i)) & bn1(i)
            If pn(i) > bn(i) Then
                td(3) = "玩家贏"
            ElseIf pn(i) < bn(i) Then
                td(3) = "莊家贏"
            Else
                td(3) = "平手"
            End If
            tr.Rows.Add(td)
        Next
        dgv.DataSource = tr
    End Sub
End Class
