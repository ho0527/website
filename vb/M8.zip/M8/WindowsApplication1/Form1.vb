﻿Public Class Form1
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim count, data(100, 5), ans(100)
        FileOpen(8, "c:\11900\1060308.sm", OpenMode.Input)
        count = 0
        Do While Not EOF(8)
            count = count + 1
            Input(8, data(count, 1))
            Input(8, data(count, 2))
            Input(8, data(count, 3))
            Input(8, data(count, 4))
            Input(8, data(count, 5))
        Loop
        FileClose(8)        For i = 1 To count
            Dim b = data(i, 1)
            Dim a = data(i, 2)
            Dim op = data(i, 3)
            Dim y = data(i, 4)
            Dim x = data(i, 5)
            Dim temptop = 0
            Dim tempdown = 0
            If op = "+" Then
                temptop = ((b * x) + (a * y))
                tempdown = (a * x)
            ElseIf op = "-" Then
                temptop = ((b * x) - (a * y))
                tempdown = (a * x)
            ElseIf op = "*" Then
                temptop = (b * y)
                tempdown = (a * x)
            Else
                temptop = (b * x)
                tempdown = (a * y)
            End If
            For j = 2 To Math.Abs(temptop)
                Do While temptop Mod j = 0 And tempdown Mod j = 0
                    temptop = temptop / j
                    tempdown = tempdown / j
                Loop
            Next
            ans(i) = temptop & "/" & tempdown
            If temptop = 0 Then ans(i) = 0
            If tempdown = 1 Then ans(i) = temptop
        Next

        Dim tr As New DataTable
        tr.Columns.Add("VALUE1")
        tr.Columns.Add("OP")
        tr.Columns.Add("VALUE2")
        tr.Columns.Add("ANSWER")
        For i = 1 To count
            Dim td As DataRow = tr.NewRow
            td(0) = data(i, 1) & "/" & data(i, 2)
            td(1) = data(i, 3)
            td(2) = data(i, 4) & "/" & data(i, 5)
            td(3) = ans(i)
            tr.Rows.Add(td)
        Next
        dgv.DataSource = tr
    End Sub
End Class
